package com.example.onlineclassquery;

import android.widget.AbsListView;

/**
 * Created by admin on 2015/12/3.
 */
public class ListViewOnScrollListener implements AbsListView.OnScrollListener {
    @Override
    public void onScrollStateChanged(AbsListView absListView, int i) {

    }

    @Override
    public void onScroll(AbsListView absListView, int i, int i1, int i2) {

    }
}
