package com.example.onlineclassquery;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by admin on 2015/12/2.
 */
public class MyDbHelper extends SQLiteOpenHelper {
    private Context context;
    private String teacher_table = "create table teachers(id text primary key,name text)";
    private String course_table = "create table courses(id,course_seq,course_day,course_content)";

    public MyDbHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(teacher_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        switch (i){
            case 2:
                sqLiteDatabase.execSQL(course_table);
                break;
        }
    }
}
